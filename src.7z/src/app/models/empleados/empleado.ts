export class IEmpleado
{
    Id:number
    Nombre: string
    AreaId: number
    Area : string
    PuestoId : number
    ApuebaPaseSalida : boolean
    Puesto: string
    Activo : boolean
    Editar : boolean
    Perfil : string
    PerfilId : number
}   