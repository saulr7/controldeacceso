export class ILogin{

    usuario: string
    password: string
}