export class IUsuario{

    Id: number
    Nombre:string;
    Usuario:string;
    PuestoId : number
    Puesto : string;
    AreaId: number
    Area : string;
    TipoUsuario : number;
}