export class IAccesos
{
    UsuarioId: number
    Usuario : string
    Pantallas : any[]
    PerfilId : number
    Perfil : string
    Activo : boolean
}