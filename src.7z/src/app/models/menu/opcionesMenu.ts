export class IOpcionMenu
{
    Id: number
    Descripcion : string
    Nombre: string
    Ruta: string
    Icono : string
}