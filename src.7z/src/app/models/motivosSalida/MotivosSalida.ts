export class IMotivosSalida{

    Id: number
    Descripcion:string
    ObservacionObligatoria:boolean
    Activo : boolean
    editar: boolean
}