export class IPerfil
{
    Activo: boolean
    Descripcion: string
    FechaCreado: Date
    Id: number
    idUsuarioCrea: number
}