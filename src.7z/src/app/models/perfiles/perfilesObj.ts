export  var Perfiles = 
    [
        {Descripcion : "Todos", valor : -1 },
        {Descripcion : "Administrador", valor : 1 },
        {Descripcion : "Estandar", valor : 2 },
        {Descripcion : "Seguridad", valor : 3 },
        
    ]
