
export class INuevaSolicitud
{
  
    idUsuarioSolicitante : number;
    idUsuarioAutoriza : number;
    idMotivoSalida : number
    Observaciones : string;
    Regresara : boolean;
    HoraSalida : string;
    HoraEntrada : string;
    idUsuarioCrea : number;
    FechaDesde : string;
    FechaHasta : string;
}