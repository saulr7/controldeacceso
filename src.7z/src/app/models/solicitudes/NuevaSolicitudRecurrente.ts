export class INuevaSolicitudRecurrente
{
    idUsuarioSolicitante : number;
    idUsuarioAutoriza : number;
    idMotivoSalida : number
    Observaciones : string;
    Regresara : boolean;
    idUsuarioCrea : number;
    FechaDesde : string;
    FechaHasta : string;
    HoraSalidaEstimada  :  string ;
    HoraEntradaEstimada  : string ;

}