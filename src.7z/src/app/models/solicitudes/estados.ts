export  enum EstadoSolicitud
{
    Pendiente = 1 ,
    Aprobada = 2,
    Denegada = 3,
    Cancelada = 4,
    Salida = 5,
    Finalizada = 6
}
