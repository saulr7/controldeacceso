export  var EstadosObj = 
    [
        {Descripcion : "Todas", valor : -1 },
        {Descripcion : "Pendiente", valor : 1 },
        {Descripcion : "Aprobada", valor : 2 },
        {Descripcion : "Denegada", valor : 3 },
        {Descripcion : "Cancelada", valor : 4 },
        {Descripcion : "Salida", valor : 5 },
        {Descripcion : "Finalizada", valor : 6 }
        
    ]
